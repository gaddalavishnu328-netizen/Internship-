const grid = document.querySelector("#internship-grid");
const searchInput = document.querySelector("#search-input");
const domainFilter = document.querySelector("#domain-filter");
const typeFilter = document.querySelector("#type-filter");
const resetButton = document.querySelector("#reset-button");
const resultCount = document.querySelector("#result-count");
const statusMessage = document.querySelector("#status-message");

let internships = [];

function initials(name) {
  return name.split(/\\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function populateDomains(records) {
  const domains = [...new Set(records.map(item => item.domain))].sort();
  domainFilter.innerHTML = '<option value="">All domains</option>';
  domains.forEach(domain => {
    const option = document.createElement("option");
    option.value = domain;
    option.textContent = domain;
    domainFilter.append(option);
  });
}

function createCard(item) {
  const article = document.createElement("article");
  article.className = "internship-card";

  const top = document.createElement("div");
  top.className = "card-top";
  const mark = document.createElement("div");
  mark.className = "company-mark";
  mark.setAttribute("aria-hidden", "true");
  mark.textContent = initials(item.company);
  const badge = document.createElement("span");
  badge.className = "work-badge";
  badge.textContent = item.type;
  top.append(mark, badge);

  const title = document.createElement("h3");
  title.textContent = item.role;
  const company = document.createElement("p");
  company.className = "company-name";
  company.textContent = item.company + " · " + item.domain;
  const description = document.createElement("p");
  description.className = "description";
  description.textContent = item.description;

  const skills = document.createElement("div");
  skills.className = "skills";
  skills.setAttribute("aria-label", "Required skills");
  item.skills.forEach(skill => {
    const tag = document.createElement("span");
    tag.className = "skill";
    tag.textContent = skill;
    skills.append(tag);
  });

  const meta = document.createElement("div");
  meta.className = "card-meta";
  [item.location, item.duration, item.stipend].forEach(value => {
    const span = document.createElement("span");
    span.textContent = value;
    meta.append(span);
  });

  const apply = document.createElement("a");
  apply.className = "apply-link";
  apply.href = item.applyUrl;
  apply.target = "_blank";
  apply.rel = "noopener noreferrer";
  apply.textContent = "View opportunity ↗";
  apply.setAttribute("aria-label", `View ${item.role} at ${item.company} (opens in a new tab)`);

  article.append(top, title, company, description, skills, meta, apply);
  return article;
}

function render(records) {
  grid.replaceChildren();
  if (!records.length) {
    resultCount.textContent = "0 opportunities";
    const empty = document.createElement("div");
    empty.className = "empty-state";
    const heading = document.createElement("h3");
    heading.textContent = "No internships found";
    const message = document.createElement("p");
    message.textContent = "Try another keyword or clear your filters to see all opportunities.";
    empty.append(heading, message);
    grid.append(empty);
    return;
  }
  resultCount.textContent = `${records.length} ${records.length === 1 ? "opportunity" : "opportunities"}`;
  records.forEach(item => grid.append(createCard(item)));
}

function applyFilters() {
  const term = searchInput.value.trim().toLowerCase();
  const domain = domainFilter.value;
  const type = typeFilter.value;
  const filtered = internships.filter(item => {
    const searchable = `${item.role} ${item.company} ${item.domain} ${item.description} ${item.skills.join(" ")}`.toLowerCase();
    return searchable.includes(term) && (!domain || item.domain === domain) && (!type || item.type === type);
  });
  render(filtered);
}

async function loadInternships() {
  statusMessage.textContent = "Loading internships…";
  try {
    const response = await fetch("data/internships.json");
    if (!response.ok) throw new Error(`Request failed: ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data)) throw new Error("The internship data has an invalid format.");
    internships = data;
    populateDomains(internships);
    statusMessage.textContent = "";
    render(internships);
  } catch (error) {
    console.error("Unable to load internship data:", error);
    resultCount.textContent = "Unable to load opportunities";
    statusMessage.textContent = "We couldn't load internships right now. Please check your connection and refresh the page.";
    grid.replaceChildren();
  }
}

searchInput.addEventListener("input", applyFilters);
domainFilter.addEventListener("change", applyFilters);
typeFilter.addEventListener("change", applyFilters);
resetButton.addEventListener("click", () => {
  // The native reset restores controls; apply filters after that reset event completes.
  requestAnimationFrame(() => applyFilters());
});

loadInternships();
