# LaunchPad — Responsive Internship Board

A beginner-friendly, framework-free internship listing interface built with semantic HTML, responsive CSS, and vanilla JavaScript.

## Features

- Responsive layout for mobile, tablet, and desktop.
- Internship cards rendered from reusable JSON data.
- Live keyword search across role, company, domain, description, and skills.
- Domain and work-type filters, including a clear-filters action.
- Empty-results and data-loading error states.
- Accessible form labels, semantic landmarks, skip link, live status announcements, and keyboard-friendly native controls.
- Reduced-motion preference support.
- No frameworks or build tools required.

## Run locally

Because the app loads JSON with `fetch`, serve the folder through a local web server instead of opening `index.html` directly.

```bash
python -m http.server 8000
```

Then visit <http://localhost:8000>.

## Project structure

```text
responsive-internship-board/
├── index.html
├── styles.css
├── app.js
├── data/
│   └── internships.json
├── screenshots/
│   └── README.md
└── README.md
```

## Customize the listings

Edit `data/internships.json`. Each record uses these fields:

- `id`, `company`, `role`, `domain`
- `location`, `type`, `duration`, `stipend`
- `description`, `skills` (array)
- `applyUrl`

The included listings are fictional sample data. Replace the example application URLs with real opportunities before publishing.

## Deploy with GitHub Pages

1. Create a **public** GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish and copy the deployed URL.

## Suggested README screenshots

After running the site locally or deploying it, capture:
1. Desktop view showing the hero and internship cards.
2. Mobile view showing the stacked filters and single-column cards.
3. A filtered search result or the no-results state.

Save the images in `screenshots/` and embed them here, for example:

```md
![Desktop preview](screenshots/desktop.png)
![Mobile preview](screenshots/mobile.png)
![Filtered results](screenshots/filtered.png)
```

## Accessibility and test checklist

- [ ] Navigate the page using only Tab, Shift+Tab, Enter, and Space.
- [ ] Confirm every filter has a visible label.
- [ ] Test search with a role, company, and skill keyword.
- [ ] Test each domain and work-type filter.
- [ ] Search for a term with no matches and confirm the empty state.
- [ ] Temporarily rename `data/internships.json` to test the load-error message.
- [ ] Check the layout at approximately 375px, 768px, and 1440px widths.
- [ ] Add real screenshots and the deployed GitHub Pages URL before submitting.

## Submission

Submit one public GitHub repository URL or one view-only project link. Keep source files, data, README, and screenshots together in that repository.
